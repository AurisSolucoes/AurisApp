  
  
  function loginTest(){
    var email = document.getElementById("user-email");          
    if (email.value == "caiotav.lima21@gmail.com") {
      window.location.href = "../web/main-page.html"
      
    }
  }