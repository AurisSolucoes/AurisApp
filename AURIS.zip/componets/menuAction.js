  
  var menuStatus = false;
 
  function menuOpen() {
    if(!menuStatus){
      console.log(menuStatus)
      menuStatus = true;
    }else {
      console.log(menuStatus)
      menuStatus = false;
    }
  }